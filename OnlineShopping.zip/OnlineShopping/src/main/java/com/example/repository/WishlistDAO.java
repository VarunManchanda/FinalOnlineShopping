package com.example.repository;

import com.example.exception.CartException;
import com.example.exception.WishlistException;

public interface WishlistDAO {
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException;
}
