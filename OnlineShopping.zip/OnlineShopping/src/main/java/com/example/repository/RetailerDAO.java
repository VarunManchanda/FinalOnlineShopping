package com.example.repository;

import java.util.List;

import com.example.dto.AddProduct;
import com.example.dto.PlacedOrder;
import com.example.dto.Product;
import com.example.dto.RetailerSignUp;
import com.example.dto.UserSignUp;
import com.example.entity.RetailerTable;
import com.example.entity.UserTable;
import com.example.exception.CustomerException;

public interface RetailerDAO {
	public int getRetailerByEmailAndPassword(String email, String password) throws CustomerException;
	public RetailerTable getRetailerByEmail(String email) throws CustomerException;
	public int addRetailer(RetailerSignUp newRetailer);
	public boolean addProduct(AddProduct product, int rId);
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer);
	public AddProduct updateProduct(AddProduct updateProduct, int pId);
	public List<Product> showMyProducts(int rId);
	public List<RetailerSignUp> showAllRetailers();
	public RetailerSignUp getRetailerById(int rId);
}
