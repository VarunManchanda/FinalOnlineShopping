package com.example.repository;

import java.util.List;

import com.example.dto.Cart;
import com.example.dto.UpdateUser;
import com.example.dto.UserSignUp;
import com.example.dto.Wishlist;
import com.example.entity.CartTable;
import com.example.entity.UserTable;
import com.example.exception.CustomerException;

public interface UserDAO {
	public List<UserTable> getAllUsers(); //for testing
	public UserTable getUserById(int uId); //for testing
	public int getUserByEmailAndPassword(String email, String password) throws CustomerException;
	public UserTable getUserByEmail(String email) throws CustomerException;
	public UserTable updateUser(long uId, UserTable user);
	public List<Cart> getCartOfUser(int uId);
	public List<Wishlist> getWishlistOfUser(int uId);
	public int addUser(UserSignUp newUser);
	public UserTable updateUser(UpdateUser updateUser);
}
