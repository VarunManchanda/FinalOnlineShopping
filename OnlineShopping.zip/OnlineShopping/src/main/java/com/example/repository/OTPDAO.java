package com.example.repository;


public interface OTPDAO {
	public int addOtp();
	public int getLastOTP();
}