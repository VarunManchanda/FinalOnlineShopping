package com.example.service;

import java.util.List;

import com.example.dto.AddProduct;
import com.example.dto.Product;
import com.example.dto.RetailerSignUp;
import com.example.entity.RetailerTable;
import com.example.exception.CustomerException;

public interface RetailerService {
	public int loginRetailer(String rEmail, String rPassword) throws CustomerException;
	public int addRetailer(RetailerSignUp newRetailer);
	public boolean addProduct(AddProduct product, int rId);
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer);
	public AddProduct updateProduct(AddProduct updateProduct, int pId);
	public List<Product> getMyProducts(int rId);
	public RetailerSignUp getRetailerById(int rId);
}
