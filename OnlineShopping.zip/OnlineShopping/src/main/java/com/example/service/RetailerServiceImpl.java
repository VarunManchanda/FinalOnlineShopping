package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.AddProduct;
import com.example.dto.Product;
import com.example.dto.RetailerSignUp;
import com.example.entity.RetailerTable;
import com.example.entity.UserTable;
import com.example.exception.CustomerException;
import com.example.repository.RetailerDAO;

@Service
public class RetailerServiceImpl implements RetailerService {
	
	
	@Autowired
	private RetailerDAO retailerDAO;

	@Override
	@Transactional
	public int addRetailer(RetailerSignUp newRetailer) {
		// TODO Auto-generated method stub
		int id = 0;
		try
		{
			RetailerTable user = this.retailerDAO.getRetailerByEmail(newRetailer.getuEmail());
			return -100;
		}
		catch(NullPointerException e)
		{
			return -100;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.retailerDAO.addRetailer(newRetailer);
		}
		return id;
	}

	@Override
	public boolean addProduct(AddProduct product, int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.addProduct(product, rId);
	}

	@Override
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer) {
		// TODO Auto-generated method stub
		return this.retailerDAO.updateRetailer(updateRetailer);
	}

	@Override
	public AddProduct updateProduct(AddProduct updateProduct, int pId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.updateProduct(updateProduct, pId);
	}

	@Override
	public List<Product> getMyProducts(int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.showMyProducts(rId);
	}

	@Override
	public int loginRetailer(String rEmail, String rPassword) throws CustomerException {
		// TODO Auto-generated method stub
		return this.retailerDAO.getRetailerByEmailAndPassword(rEmail, rPassword);
	}

	@Override
	public RetailerSignUp getRetailerById(int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.getRetailerById(rId);
	}
	
}
