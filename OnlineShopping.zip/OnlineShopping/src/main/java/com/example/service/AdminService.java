package com.example.service;

import java.util.List;

import com.example.dto.RetailerSignUp;

public interface AdminService {
	public List<RetailerSignUp> showAllRetailers();
}
