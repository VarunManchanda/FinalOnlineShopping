package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.RetailerSignUp;
import com.example.repository.RetailerDAO;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private RetailerDAO retailerDAO;
	
	@Override
	public List<RetailerSignUp> showAllRetailers() {
		// TODO Auto-generated method stub
		return this.retailerDAO.showAllRetailers();
	}

}
