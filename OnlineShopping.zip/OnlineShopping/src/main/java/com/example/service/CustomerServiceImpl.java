	package com.example.service;

import java.util.List;

import javax.persistence.NonUniqueResultException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.Cart;
import com.example.dto.ForgotPassword;
import com.example.dto.Login;
import com.example.dto.PlacedOrder;
import com.example.dto.UpdateUser;
import com.example.dto.UserSignUp;
import com.example.dto.Wishlist;
import com.example.entity.CartTable;
import com.example.entity.UserTable;
import com.example.exception.CartException;
import com.example.exception.CustomerException;
import com.example.exception.WishlistException;
import com.example.repository.CartDAO;
import com.example.repository.OTPDAO;
import com.example.repository.PlaceOrderDAO;
import com.example.repository.UserDAO;
import com.example.repository.WishlistDAO;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private OTPDAO otpDAO;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	private WishlistDAO wishlistDAO;
	
	@Autowired
	private PlaceOrderDAO placeOrderDAO;
	
	
	public int generateOTP()
	{
		return this.otpDAO.addOtp();
	}
	
	@Override
	@Transactional
	public boolean forgotPassword(ForgotPassword forgotPassword) {
		// TODO Auto-generated method stub
		//Logic:- first generate new otp, then check if what user put is same then update
		int otp = this.otpDAO.getLastOTP();
		if(Integer.parseInt(forgotPassword.getOtp())==otp)
		{
			System.out.println("OTP Matched!");
			UserTable userTable = (UserTable)this.userDAO.getUserByEmail(forgotPassword.getEmail());
			userTable.setUPassword(forgotPassword.getPassword());
			this.userDAO.updateUser(userTable.getUId(), userTable);
			return true;
		}
		return false;
	}

	@Override
	public int login(Login login) throws CustomerException{
		int id = this.userDAO.getUserByEmailAndPassword(login.getEmail(),login.getPassword());
		return id;
	}

	@Override
	public UserTable getUserById(int uId) {
		// TODO Auto-generated method stub
		return this.userDAO.getUserById(uId);
	}

	@Override
	public List<Cart> getCartValues(int uId) {
		// TODO Auto-generated method stub
		return this.userDAO.getCartOfUser(uId);
	}

	@Override
	public List<Wishlist> getWishlistValues(int uId) {
		// TODO Auto-generated method stub
		return this.userDAO.getWishlistOfUser(uId);
	}

	@Override
	public boolean addToCart(int uId, int pId) {
		// TODO Auto-generated method stub
		return this.cartDAO.addToCart(uId, pId);
	}

	@Override
	public boolean updateCart(int cId, int addOrMinus) {
		// TODO Auto-generated method stub
		return this.cartDAO.updateCart(cId,addOrMinus);
	}

	@Override
	public boolean deleteCart(int cId) throws CartException {
		// TODO Auto-generated method stub
		return this.cartDAO.deleteCart(cId);
	}

	@Override
	public boolean addToWishlist(int uId, int pId) {
		// TODO Auto-generated method stub
		return this.wishlistDAO.addToWishlist(uId, pId);
	}

	@Override
	public boolean deleteWishlist(int wId) throws WishlistException {
		// TODO Auto-generated method stub
		return this.wishlistDAO.deleteWishlist(wId);
	}

	@Override
	public boolean placeOrder(List<Cart> carts, String payType) {
		// TODO Auto-generated method stub
		return this.placeOrderDAO.placeOrder(carts,payType);
	}

	@Override
	public List<PlacedOrder> getMyPlacedOrders(int uId) {
		// TODO Auto-generated method stub
		return this.placeOrderDAO.showPlacedOrders(uId);
	}

	@Override
	public int addUser(UserSignUp newUser) {
		// TODO Auto-generated method stub
		//first check if user is present or not!
		int id = 0;
		try
		{
			UserTable user = this.userDAO.getUserByEmail(newUser.getuEmail());
			return -100;
		}
		catch(NullPointerException e)
		{
			return -100;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.userDAO.addUser(newUser);
		}
		return id;
	}

	@Override
	public UserTable updateUser(UpdateUser updateUser) {
		// TODO Auto-generated method stub
		return this.userDAO.updateUser(updateUser);
	}
	

}
