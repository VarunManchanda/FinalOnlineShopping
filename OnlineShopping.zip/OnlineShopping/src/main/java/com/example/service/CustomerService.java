package com.example.service;

import java.util.List;

import com.example.dto.Cart;
import com.example.dto.ForgotPassword;
import com.example.dto.Login;
import com.example.dto.PlacedOrder;
import com.example.dto.UpdateUser;
import com.example.dto.UserSignUp;
import com.example.dto.Wishlist;
import com.example.entity.CartTable;
import com.example.entity.UserTable;
import com.example.exception.CartException;
import com.example.exception.CustomerException;
import com.example.exception.WishlistException;

public interface CustomerService {
	public int generateOTP();
	public int login(Login login) throws CustomerException; //passed
	public boolean forgotPassword(ForgotPassword forgotPassword); //passed
	public UserTable getUserById(int uId); //only for testing purpose
	public List<Cart> getCartValues(int uId); //passed
	public List<Wishlist> getWishlistValues(int uId);
	public boolean addToCart(int uId, int pId);
	public boolean updateCart(int cId, int addOrMinus);
	public boolean deleteCart(int cId) throws CartException;
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException;
	public boolean placeOrder(List<Cart> carts, String payType);
	public List<PlacedOrder> getMyPlacedOrders(int uId);
	public int addUser(UserSignUp newUser);
	public UserTable updateUser(UpdateUser updateUser);
}
