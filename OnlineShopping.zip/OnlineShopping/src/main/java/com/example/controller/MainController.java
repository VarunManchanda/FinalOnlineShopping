package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.AddProduct;
import com.example.dto.Cart;
import com.example.dto.ForgotPassword;
import com.example.dto.Login;
import com.example.dto.PlacedOrder;
import com.example.dto.Product;
import com.example.dto.RetailerSignUp;
import com.example.dto.UpdateRetailer;
import com.example.dto.UpdateUser;
import com.example.dto.UserSignUp;
import com.example.dto.Wishlist;
import com.example.entity.CartTable;
import com.example.entity.ProductTable;
import com.example.entity.RetailerTable;
import com.example.entity.UserTable;
import com.example.exception.CustomerException;
import com.example.service.AdminService;
import com.example.service.CustomerService;
import com.example.service.ProductService;
import com.example.service.RetailerService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MainController {

	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private RetailerService retailerService;
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping(path = "/index")   //passed
	public String home()
	{
		return "Welcome, to ShopCart.com ";
	}
	@PostMapping(path = "/login") //passed
	public int login(@RequestBody Login login)
	{
		try {
			return this.customerService.login(login);
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}
	@GetMapping(path = "/generateOTP") //passed
	public int generateOTP()
	{
		return this.customerService.generateOTP();
	}
	
	@GetMapping(path = "/getUserById/{uId}") //passed
	public UserTable getUserById(@PathVariable String uId)
	{
		UserTable user = this.customerService.getUserById(Integer.parseInt(uId));
		return user;
	}
	
	@GetMapping(path = "/addToMyCart/{uId}/{pId}") //passed
	public String addToMyCart(@PathVariable String uId, @PathVariable String pId)
	{
		boolean ok = this.customerService.addToCart(Integer.parseInt(uId),Integer.parseInt(pId));
		if(ok==true)
			return "Product Added to Cart Successfull";
		return "Cannot Add Product to Cart";
	}
	
	
	@GetMapping(path = "/addToMyWishlist/{uId}/{pId}") //passed
	public String updateMyWishlist(@PathVariable String uId, @PathVariable String pId)
	{
		boolean ok = this.customerService.addToWishlist(Integer.parseInt(uId),Integer.parseInt(pId));
		if(ok==true)
			return "Product Added to Wishlist Successfull";
		return "Cannot Add Product to Wishlist";
	}
	
	@DeleteMapping(path = "/deleteMyWishlist/{wId}") //passed
	public ResponseEntity<HttpStatus> deleteMyWishlist(@PathVariable String wId)
	{
		try
		{
			boolean ok = this.customerService.deleteWishlist(Integer.parseInt(wId));
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping(path = "/updateMyCart/{cId}/{addOrMinus}") //passed
	public String updateMyCart(@PathVariable String cId, @PathVariable String addOrMinus)
	{
		boolean ok = this.customerService.updateCart(Integer.parseInt(cId),Integer.parseInt(addOrMinus));
		if(ok==true)
			return "Cart Updated Successfull";
		return "Cannot Update Cart";
	}
	
	@DeleteMapping(path = "/deleteMyCart/{cId}") //passed
	public ResponseEntity<HttpStatus> deleteMyCart(@PathVariable String cId)
	{
		try
		{
			boolean ok = this.customerService.deleteCart(Integer.parseInt(cId));
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping(path = "/getMyCart/{uId}") //passed
	public List<Cart> getMyCart(@PathVariable String uId)
	{
		return this.customerService.getCartValues(Integer.parseInt(uId));
	}
	
	@GetMapping(path = "/getMyWishlist/{uId}") //passed
	public List<Wishlist> getMyWishlist(@PathVariable String uId)
	{
		return this.customerService.getWishlistValues(Integer.parseInt(uId));
	}
	
	@PostMapping(path = "/forgotPassword") //passed
	public String login(@RequestBody ForgotPassword forgotPassword)
	{
		boolean ok = this.customerService.forgotPassword(forgotPassword);
		if(ok==true)
			return "Password Updated Successfull";
		return "Password Updated Failure";
	}
	
	@GetMapping(path = "/getProductById/{pId}") //passed
	public Product getProductById(@PathVariable String pId)
	{
		return this.productService.getProductById(Integer.parseInt(pId));
	}
	
	@GetMapping(path = "/getProductBySearch/{pSearch}") //passed
	public List<Product> getProductBySearch(@PathVariable String pSearch)
	{
		return this.productService.getProductBySearch(pSearch);
	}
	
	@GetMapping(path = "/sortProduct/{by}/{order}") //passed
	public List<Product> sortProduct(@PathVariable String by, @PathVariable String order)
	{
		return this.productService.sortProduct(by, Integer.parseInt(order));
	}
	
	@GetMapping(path = "/filterProduct/{brand}/{s}/{e}") //passed
	public List<Product> sortProduct(@PathVariable String brand, @PathVariable String s, @PathVariable String e)
	{
		return this.productService.filterProduct(brand, Integer.parseInt(s), Integer.parseInt(e));
	}
	
	@PostMapping(path = "/placeOrder/{payType}") //passed
	public String placeOrder(@RequestBody List<Cart> carts, @PathVariable String payType)
	{
		boolean ok = this.customerService.placeOrder(carts,payType);
		if(ok==true)
			return "Order Place Successfull";
		return "Order Place Failure";
	}
	
	@GetMapping(path = "/getMyPlacedOrders/{uId}") //passed
	public List<PlacedOrder> sortProduct(@PathVariable String uId)
	{
		return this.customerService.getMyPlacedOrders(Integer.parseInt(uId));
	}
	 
	@PostMapping(path = "/addNewUser") //passed
	public int addNewUser(@RequestBody UserSignUp newUser)
	{
		return this.customerService.addUser(newUser);
	}
	
	@PostMapping(path = "/addNewRetailer") //passed
	public int addNewRetailer(@RequestBody RetailerSignUp newRetailer)
	{
		return this.retailerService.addRetailer(newRetailer);
	}
	 
	@PostMapping(path = "/addProduct/{rId}") //passed
	public boolean addProduct(@RequestBody AddProduct product, @PathVariable String rId)
	{
		return this.retailerService.addProduct(product, Integer.parseInt(rId));
	}
	
	@PutMapping(path = "/updateUser") //passed
	public UserTable updateUser(@RequestBody UpdateUser updateUser)
	{
		return this.customerService.updateUser(updateUser);
	}
	 
	@PutMapping(path = "/updateRetailer") //passed
	public RetailerTable updateRetailer(@RequestBody RetailerSignUp updateRetailer)
	{
		return this.retailerService.updateRetailer(updateRetailer);
	}
	
	@PutMapping(path = "/updateProduct/{pId}") //passed
	public AddProduct updateProduct(@RequestBody AddProduct updateProduct, @PathVariable String pId)
	{
		return this.retailerService.updateProduct(updateProduct, Integer.parseInt(pId));
	}
	
	@GetMapping(path = "/getMyProduct/{rId}")
	public List<Product> getMyProduct(@PathVariable String rId)
	{
		return this.retailerService.getMyProducts(Integer.parseInt(rId));
	}
	@PostMapping(path = "/retailerLogin") //passed
	public int retailerLogin(@RequestBody Login login)
	{
		try {
			return this.retailerService.loginRetailer(login.getEmail(), login.getPassword());
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}
	@GetMapping(path = "/showAllRetailers")
	public List<RetailerSignUp> showAllRetailers()
	{
		return this.adminService.showAllRetailers();
	}
	@GetMapping(path = "/getRetailerById/{rId}")
	public RetailerSignUp getRetailerById(@PathVariable String rId)
	{
		return this.retailerService.getRetailerById(Integer.parseInt(rId));
	}
	
	
	
	
}
