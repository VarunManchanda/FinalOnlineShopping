package com.example.dto;

public class UpdateRetailer {

}
