import { Component, OnInit } from '@angular/core';
import { Login } from '../DTO/Login.dto';
import { ProductServiceService } from '../Service/product-service.service';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../Service/customer-service.service';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  registerForm: FormGroup;
    submitted = false;


  login: Login;
  email: string = "";
  password: string = "";
  uId$ : Observable<number>;

  constructor
    (private formBuilder: FormBuilder,
      private _customerService : CustomerServiceService,
    private _router : Router) { }

  ngOnInit(): void {
    if(parseInt(sessionStorage.getItem('user'))>0)
    {
      alert("Already Logged In");
      this._router.navigate(['home']);
    }
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(2)]]
  });
  }

  loginUser()
  {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
else{
    this.login = new Login();
    this.login.email = this.email;
    this.login.password = this.password;
    this.uId$ = this._customerService.login(this.login);
    //alert(this.login.email);
}
  }

  moveToHomePage(id)
  {
    if(id<0)
    {
      alert('User Not Found');
      this.uId$ = null;
      return;
    }
    sessionStorage.setItem('user',id);
    this._router.navigate(['home']);
  }

  forgotPassword()
  {
    if(this.email==="")
    {
      alert("Provide email");
      return;
    }
    sessionStorage.setItem('forgot-email',this.email);
    this._router.navigate(['forgot-password']);
  }
  get f() { return this.registerForm.controls; }

  
}