import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { DisplayAllProductsComponent } from './display-all-products/display-all-products.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SingleProductComponent } from './single-product/single-product.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { UserCartComponent } from './user-cart/user-cart.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { UserMyorderComponent } from './user-myorder/user-myorder.component';
import { UserPlaceOrderComponent } from './user-place-order/user-place-order.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminProfileComponent } from './admin-profile/admin-profile.component';
import { CompareProductsComponent } from './compare-products/compare-products.component';
import { RetailerLoginComponent } from './retailer-login/retailer-login.component';
import { RetailerProfileComponent } from './retailer-profile/retailer-profile.component';
import { UserWishlistComponent } from './user-wishlist/user-wishlist.component';
import { RetailerProductsComponent } from './retailer-products/retailer-products.component';
import { RetailerUpdateProductComponent } from './retailer-update-product/retailer-update-product.component';
import { AdminRetailersComponent } from './admin-retailers/admin-retailers.component';
const routes: Routes = 
[
  {path : '', redirectTo : '/home', pathMatch: 'full'},
  {path : 'home', component : HomeComponent},
  {path : 'header', component : HeaderComponent},
  {path : 'display-all-products/:keyword', component: DisplayAllProductsComponent},
  {path : 'display-single-product/:id', component: SingleProductComponent},
  {path : 'user-login', component: UserLoginComponent},
  {path : 'forgot-password', component: ForgotPasswordComponent},
  {path : 'register-user', component: RegisterUserComponent},
  {path : 'user-cart', component: UserCartComponent},
  {path : 'user-profile', component: UserProfileComponent},
  {path : 'user-edit', component: EditUserComponent},
  {path : 'user-myorder', component: UserMyorderComponent},
  {path : 'user-placeorder', component: UserPlaceOrderComponent},
  {path : 'admin-login', component: AdminLoginComponent},
  {path : 'admin-profile', component: AdminProfileComponent},
  {path : 'compare-product', component: CompareProductsComponent},
  {path : 'retailer-login', component: RetailerLoginComponent},
  {path : 'retailer-profile', component: RetailerProfileComponent},
  {path : 'user-wishlist', component: UserWishlistComponent},
  {path : 'retailer-products', component: RetailerProductsComponent},
  {path : 'retailer-update-product', component: RetailerUpdateProductComponent},
  {path : 'admin-retailer', component: AdminRetailersComponent},
  {path : '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
