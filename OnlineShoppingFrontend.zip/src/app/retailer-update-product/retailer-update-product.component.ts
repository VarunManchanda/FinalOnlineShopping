import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RetailerServiceService } from '../Service/retailer-service.service';
import { ProductServiceService } from '../Service/product-service.service';
import { AddProduct } from '../DTO/AddProduct.dto';

@Component({
  selector: 'app-retailer-update-product',
  templateUrl: './retailer-update-product.component.html',
  styleUrls: ['./retailer-update-product.component.css']
})
export class RetailerUpdateProductComponent implements OnInit {

  product =  new AddProduct();
  constructor(
    private _router : Router,
    private _retailerService : RetailerServiceService,
    private _productService : ProductServiceService
  ) { }

  ngOnInit(): void {
    let rId = sessionStorage.getItem('retailer');
    if(rId!="null")
    {
    } 
    else
    {
      alert("Retailer Not Logged In");
      this._router.navigate(['home']);
    }
  }
  onEditProduct()
  {
    this._retailerService.updateProduct(this.product,sessionStorage.getItem('pId'))
      .subscribe(data=>
      {
        alert("Product Updated Successfull");
        this._router.navigate(['retailer-products']);
      });
  }

}
