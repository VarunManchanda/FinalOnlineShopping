import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Retailer } from '../DTO/RetailerSignUp.dto';
import { RetailerServiceService } from '../Service/retailer-service.service';

@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.css']
})
export class AdminProfileComponent implements OnInit {

  newRetailer = new  Retailer();
  constructor
  (
    private _router : Router,
    private _retailerService : RetailerServiceService
  ) { }

  ngOnInit(): void {
    if(sessionStorage.getItem('admin')=="null")
    {
      alert("Admin Not Logged In");
      this._router.navigate(['home']);
    }
  }

  addRetailer()
  {
    this._retailerService.addNewRetailer(this.newRetailer)
    .subscribe(data=>
      {
        if(data==-100)
        {
          alert("Retailer already Exists");
        }
        else
        {
          alert("New Retailer Added");
        }
      })
  }

}
