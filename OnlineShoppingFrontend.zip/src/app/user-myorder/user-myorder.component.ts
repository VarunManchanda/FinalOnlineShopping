import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../Service/customer-service.service';
import { PlacedOrder } from '../DTO/PlacedOrder.dto';
import { Router } from '@angular/router';
@Component({
  selector: 'app-user-myorder',
  templateUrl: './user-myorder.component.html',
  styleUrls: ['./user-myorder.component.css']
})
export class UserMyorderComponent implements OnInit {

  myOrders : PlacedOrder[];
  constructor
  (
    private _customerService : CustomerServiceService,
    private _router : Router
  ) { }

  ngOnInit(): void 
  {
    if(sessionStorage.getItem('user')!="null")
    {
      this._customerService.getMyPlacedOrders(sessionStorage.getItem('user'))
      .subscribe((data:PlacedOrder[])=>{
        this.myOrders = data;
      });
    }
    else
    {
      alert("User Not Logged In");
      this._router.navigate(['home']);
    }
    
  }

}
