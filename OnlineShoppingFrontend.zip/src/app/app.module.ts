//Angular Specific imports
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
//Routing imports
import { AppRoutingModule } from './app-routing.module';
//Component imports
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DisplayAllProductsComponent } from './display-all-products/display-all-products.component';
import { RetailerServiceService } from 'src/app/Service/retailer-service.service';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SingleProductComponent } from './single-product/single-product.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { UserCartComponent } from './user-cart/user-cart.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { UserMyorderComponent } from './user-myorder/user-myorder.component';
import { UserPlaceOrderComponent } from './user-place-order/user-place-order.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminProfileComponent } from './admin-profile/admin-profile.component';
import { CompareProductsComponent } from './compare-products/compare-products.component';
import { RegisterRetailerComponent } from './register-retailer/register-retailer.component';
import { RetailerLoginComponent } from './retailer-login/retailer-login.component';
import { RetailerProfileComponent } from './retailer-profile/retailer-profile.component';
import { UserWishlistComponent } from './user-wishlist/user-wishlist.component';
import { RetailerHeaderComponent } from './retailer-header/retailer-header.component';
import { RetailerProductsComponent } from './retailer-products/retailer-products.component';
import { RetailerUpdateProductComponent } from './retailer-update-product/retailer-update-product.component';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { AdminRetailersComponent } from './admin-retailers/admin-retailers.component';
//Service imports
import { ProductServiceService } from 'src/app/Service/product-service.service';
import { CustomerServiceService } from 'src/app/Service/customer-service.service';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    DisplayAllProductsComponent,
    HomeComponent,
    PageNotFoundComponent,
    SingleProductComponent,
    UserLoginComponent,
    ForgotPasswordComponent,
    RegisterUserComponent,
    UserCartComponent,
    UserProfileComponent,
    EditUserComponent,
    UserMyorderComponent,
    UserPlaceOrderComponent,
    AdminLoginComponent,
    AdminProfileComponent,
    CompareProductsComponent,
    RegisterRetailerComponent,
    RetailerLoginComponent,
    RetailerProfileComponent,
    UserWishlistComponent,
    RetailerHeaderComponent,
    RetailerProductsComponent,
    RetailerUpdateProductComponent,
    AdminHeaderComponent,
    AdminRetailersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ProductServiceService,CustomerServiceService,RetailerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
