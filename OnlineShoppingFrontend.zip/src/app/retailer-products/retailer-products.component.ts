import { Component, OnInit } from '@angular/core';
import { RetailerServiceService } from '../Service/retailer-service.service';
import { Product } from '../DTO/Product.dto';
import { Router } from '@angular/router';

@Component({
  selector: 'app-retailer-products',
  templateUrl: './retailer-products.component.html',
  styleUrls: ['./retailer-products.component.css']
})
export class RetailerProductsComponent implements OnInit {

  products: Product[] = [];
  constructor
  (
    private _retailerService : RetailerServiceService,
    private _router : Router
  ) { }

  ngOnInit(): void 
  {
    let rId = sessionStorage.getItem('retailer');
    if(rId!="null")
    {
      this._retailerService.getMyProduct(rId)
      .subscribe((data: Product[])=>{console.log(data);this.products=data});
    } 
    else
    {
      alert("Retailer Not Logged In");
      this._router.navigate(['home']);
    }
  }
  updateProductById(product)
  {
    sessionStorage.setItem('pId',product.pId);
    this._router.navigate(['retailer-update-product']);
  }

}
