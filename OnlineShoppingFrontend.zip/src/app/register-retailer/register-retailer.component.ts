import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-retailer',
  templateUrl: './register-retailer.component.html',
  styleUrls: ['./register-retailer.component.css']
})
export class RegisterRetailerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
