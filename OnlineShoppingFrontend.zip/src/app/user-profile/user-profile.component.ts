import { Component, OnInit } from '@angular/core';
import { UserDetails } from '../DTO/UserDetails.dto';
import { CustomerServiceService } from '../Service/customer-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  User: UserDetails;
  uId: number;
  constructor(
    private _customerService : CustomerServiceService,
    private _router : Router
  ) { }

  ngOnInit(): void 
  {
    if(sessionStorage.getItem('user')!="null")
    {
      this.uId = parseInt(sessionStorage.getItem('user'));
    this._customerService.getUserById(this.uId.toString())
    .subscribe(data=>
      {
        this.User = data;
      });
    }
    else
    {
      alert("User Not Logged In");
      this._router.navigate(['home']);
    }
    
  }

  onEditProfileClick()
  {
    sessionStorage.setItem('user-details',JSON.stringify(this.User));
    this._router.navigate(['user-edit']);
  }

}
