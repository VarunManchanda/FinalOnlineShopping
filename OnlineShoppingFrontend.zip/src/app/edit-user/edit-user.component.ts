import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../Service/customer-service.service';
import { UpdateUser } from '../DTO/UpdateUser.dto';
import { Router } from '@angular/router';
import { UserDetails } from '../DTO/UserDetails.dto';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  updateUser : UpdateUser;
  newUpdatedUser;
  oldUser : UserDetails;
  constructor
  (
    private _customerService : CustomerServiceService,
    private _router : Router
  ) 
  {
    this.updateUser = new UpdateUser();
  }

  ngOnInit(): void
  {
    if(sessionStorage.getItem('user')=="null")
    {
      alert("User Not Logged In");
      this._router.navigate(['home']);
    }
    else
    {
      this.oldUser = JSON.parse(sessionStorage.getItem('user-details'));
    }
  }

  onUpdateUserClick()
  {
    let uId = parseInt(sessionStorage.getItem('user'));
    this.updateUser.uId = uId;
    console.log(this.updateUser);
    this._customerService.updateUser(this.updateUser)
    .subscribe((data)=>
      {
        this.newUpdatedUser = data;
        if(this.newUpdatedUser==-100)
        {
          alert("Your Profile Not Updated");
        }
        else
        {
          alert("Profile Updated Successfull");
          this._router.navigate(['user-profile']);
        }
      })
  }

}
