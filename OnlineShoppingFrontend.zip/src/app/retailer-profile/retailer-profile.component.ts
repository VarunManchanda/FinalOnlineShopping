import { Component, OnInit } from '@angular/core';
import { AddProduct } from '../DTO/AddProduct.dto';
import { RetailerServiceService } from '../Service/retailer-service.service';
import { Retailer } from '../DTO/RetailerSignUp.dto';
import { Router } from '@angular/router';

@Component({
  selector: 'app-retailer-profile',
  templateUrl: './retailer-profile.component.html',
  styleUrls: ['./retailer-profile.component.css']
})
export class RetailerProfileComponent implements OnInit {

  retailer : Retailer;
  constructor
  (
    private _retailerService : RetailerServiceService,
    private _router : Router
  ) { }
  rId : number;
  product = new AddProduct();
  ngOnInit(): void {
    if(parseInt(sessionStorage.getItem('retailer'))>0)
    {
      this.rId = parseInt(sessionStorage.getItem('retailer'));
      this._retailerService.getRetailerById(sessionStorage.getItem('retailer'))
      .subscribe(data=>{
        this.retailer = data;
      });
    }
    else
    {
      alert("Retaier Not Logged In");
      this._router.navigate(['home']);
    }
  }
  onAddProduct()
  {
    this._retailerService.addProduct(this.product,this.rId.toString())
    .subscribe(data=>{
      alert(data);
    })
  }

}
