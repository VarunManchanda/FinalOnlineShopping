import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../DTO/Login.dto';
import { AddProduct } from '../DTO/AddProduct.dto';
import { Product } from '../DTO/Product.dto';
import { Retailer } from '../DTO/RetailerSignUp.dto';
@Injectable({
  providedIn: 'root'
})
export class RetailerServiceService {

  private _tempurl =  'http://localhost:8090/';
  private _url =      'http://localhost:8090/';
  constructor(private _http : HttpClient) { }

  login(login : Login) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'retailerLogin';
    return this._http.post<number>(this._url,login);
  }

  addProduct(newProduct:AddProduct,rId: string)
  {
    this._url = this._tempurl;
    this._url += 'addProduct/' + rId;
    return this._http.post(this._url,newProduct);
  }
  getMyProduct(rId: string) : Observable<Product[]>
  {
    this._url = this._tempurl;
    this._url += 'getMyProduct/' + rId;
    return this._http.get<Product[]>(this._url);
  }
  getRetailerById(rId: string) : Observable<Retailer>
  {
    this._url = this._tempurl;
    this._url += 'getRetailerById/' + rId;
    return this._http.get<Retailer>(this._url);
  }
  updateProduct(updateProduct : AddProduct, pId: string) : Observable<AddProduct>
  {
    this._url = this._tempurl;
    this._url += 'updateProduct/' + pId;
    return this._http.put<AddProduct>(this._url,updateProduct);
  }
  addNewRetailer(newRetailer:Retailer) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'addNewRetailer';
    return this._http.post<number>(this._url,newRetailer);
  }
  showAllRetailers() : Observable<Retailer[]>
  {
    this._url = this._tempurl;
    this._url += 'showAllRetailers';
    return this._http.get<Retailer[]>(this._url);
  }

}
