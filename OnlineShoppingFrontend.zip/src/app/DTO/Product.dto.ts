export class Product
{
    pImage1 : string;
    pImage2 : string;
    pImage3 : string;
    pImage4 : string;
    pDescription : string;
    pId : number;
    pName : string;
    pBrand : string;
    pPrice : number;
}