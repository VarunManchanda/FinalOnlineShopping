export class UserDetails
{
    uaddress:string;
    uemail:string;
    uid: number;
    umobile: number;
    uname:string;
    upassword:string;
}