export class UpdateUser
{
    uId : number;
	uName : string;
	uEmail : string;
    uPassword : string;
	uAddress : string;
	uPhone : number;
}