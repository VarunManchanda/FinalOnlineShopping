export class UserSignUp
{
    uName : string;
	uEmail : string;
	uPassword : string;
	uAddress : string;
	uPhone : number;
}