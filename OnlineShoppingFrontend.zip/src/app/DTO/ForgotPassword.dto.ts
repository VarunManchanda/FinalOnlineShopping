export class ForgotPassword
{
    email : string;
	password : string;
	otp : string;
}