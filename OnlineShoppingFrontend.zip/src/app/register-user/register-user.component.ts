import { Component, OnInit } from '@angular/core';
import { UserSignUp } from '../DTO/UserSignUp.dto';
import { CustomerServiceService } from '../Service/customer-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  userSignUp : UserSignUp;
  constructor(
    private _customerService : CustomerServiceService,
    private _router : Router
  ) 
  {
    this.userSignUp = new UserSignUp();
  }

  ngOnInit(): void
  {
    if(parseInt(sessionStorage.getItem('user'))>0)
    {
      alert('Already Logged In');
      this._router.navigate(['home']);
    }
  }

  onRegisterClick()
  {
    
    this._customerService.addNewUser(this.userSignUp)
    .subscribe(data=>
      {
        if(data == -100)
        { 
          alert("User Already Registered");
        }
        else
        {
          this._router.navigate(['user-login']);
        }
      });
  }

}
